<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Hewan_m extends CI_Model {

    private $table = 'hewan'; // Nama tabel di database

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function get_all()
    {
        return $this->db->get($this->table)->result_array();
    }

    public function insert_hewan($data)
    {
        return $this->db->insert($this->table, $data);
    }

    public function get_by_id($id)
    {
        return $this->db->get_where($this->table, ['no' => $id])->row_array();
    }

    public function update_hewan($id, $data)
    {
        $this->db->where('no', $id);
        return $this->db->update($this->table, $data);
    }

    public function delete_hewan($id)
    {
        $this->db->where('no', $id);
        return $this->db->delete($this->table);
    }
}