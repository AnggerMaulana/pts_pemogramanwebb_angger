<?php
class Angger extends CI_Controller {
  
  public function index() {
    $this->load->view("template/head");
    $this->load->view("template/sidebar");
    $this->load->view("Angger_v");
    $this->load->view("template/footer");
  }
}