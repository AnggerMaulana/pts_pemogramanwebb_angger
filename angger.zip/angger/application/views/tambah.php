<?php $this->load->view('template/head'); ?>
<?php $this->load->view('template/sidebar'); ?>

<div class="main-panel">
				<div class="content">
					<div class="container-fluid">
						<h4 class="page-title">ANGGERRRRRRRR</h4>
						<div class="row">
							<div class="col-md-3">
								<div class="card card-stats card-warning">
</div>
</div>
												</div>
            <div class="card-body">
                <h5 class="card-title">TAMBAH HEWAN</h5>
                <form action="<?php echo base_url('index.php/hewan/tambah_aksi'); ?>" method="POST">
                    <div class="mb-3">
                        <label for="nama" class="form-label">Nama Hewan</label>
                        <select class="form-control" id="nama" name="nama" required>
                            <option value="">Pilih Nama Hewan</option>
                            <option value="Kucing">Kucing</option>
                            <option value="Anjing">Anjing</option>
                            <option value="Kambing">Kambing</option>
                            <option value="Sapi">Sapi</option>
                            <option value="Kuda">Kuda</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="jenis" class="form-label">Jenis Hewan</label>
                        <select class="form-control" id="jenis" name="jenis" required>
                            <option value="">Pilih Jenis Hewan</option>
                            <option value="Mamalia">Mamalia</option>
                            <option value="Burung">Burung</option>
                            <option value="Ikan">Ikan</option>
                            <option value="Reptil">Reptil</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="warna" class="form-label">Warna Hewan</label>
                        <select class="form-control" id="warna" name="warna" required>
                            <option value="">Pilih Warna Hewan</option>
                            <option value="Hitam">Hitam</option>
                            <option value="Putih">Putih</option>
                            <option value="Cokelat">Cokelat</option>
                            <option value="Abu-abu">Abu-abu</option>
                            <option value="Lain-lain">Lain-lain</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="stok" class="form-label">Stok</label>
                        <select class="form-control" id="stok" name="stok" required>
                            <option value="">Pilih Stok</option>
                            <option value="1">1</option>
                            <option value="5">5</option>
                            <option value="10">10</option>
                            <option value="20">20+</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="harga" class="form-label">Harga</label>
                        <select class="form-control" id="harga" name="harga" required>
                            <option value="">Pilih Harga</option>
                            <option value="10000">Rp 10.000</option>
                            <option value="50000">Rp 50.000</option>
                            <option value="100000">Rp 100.000</option>
                            <option value="500000">Rp 500.000+</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                    <a href="<?php echo site_url('index.php/hewan'); ?>" class="btn btn-secondary">Batal</a>
                </form>
            </div>
        </div>
    </div>
</div>
</div>
<?php $this->load->view('template/footer'); ?>