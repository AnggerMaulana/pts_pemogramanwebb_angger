<?php $this->load->view('template/head'); ?>
<?php $this->load->view('template/sidebar'); ?>

<div class="main-panel">
				<div class="content">
					<div class="container-fluid">
						<h4 class="page-title">ANGGERRRRRRRR</h4>
						<div class="row">
							<div class="col-md-3">
								<div class="card card-stats card-warning">
</div>
</div>
												</div>
            <div class="card-body">
                <h5 class="card-title">Edit Data Hewan</h5>
                <form action="<?php echo site_url('index.php/hewan/edit_aksi'); ?>" method="POST">
                    <input type="hidden" name="no" value="<?php echo $hewan['no']; ?>">
                    <div class="mb-3">
                        <label for="nama" class="form-label">Nama Hewan</label>
                        <select class="form-control" id="nama" name="nama" required>
                            <option value="">Pilih Nama Hewan</option>
                            <option value="Kucing" <?php if ($hewan['nama'] == 'Kucing') echo 'selected'; ?>>Kucing</option>
                            <option value="Anjing" <?php if ($hewan['nama'] == 'Anjing') echo 'selected'; ?>>Anjing</option>
                            <option value="Kambing" <?php if ($hewan['nama'] == 'Kambing') echo 'selected'; ?>>Kambing</option>
                            <option value="Sapi" <?php if ($hewan['nama'] == 'Sapi') echo 'selected'; ?>>Sapi</option>
                            <option value="Kuda" <?php if ($hewan['nama'] == 'Kuda') echo 'selected'; ?>>Kuda</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="jenis" class="form-label">Jenis Hewan</label>
                        <select class="form-control" id="jenis" name="jenis" required>
                            <option value="">Pilih Jenis Hewan</option>
                            <option value="Mamalia" <?php if ($hewan['jenis'] == 'Mamalia') echo 'selected'; ?>>Mamalia</option>
                            <option value="Burung" <?php if ($hewan['jenis'] == 'Burung') echo 'selected'; ?>>Burung</option>
                            <option value="Ikan" <?php if ($hewan['jenis'] == 'Ikan') echo 'selected'; ?>>Ikan</option>
                            <option value="Reptil" <?php if ($hewan['jenis'] == 'Reptil') echo 'selected'; ?>>Reptil</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="warna" class="form-label">Warna Hewan</label>
                        <select class="form-control" id="warna" name="warna" required>
                            <option value="">Pilih Warna Hewan</option>
                            <option value="Hitam" <?php if ($hewan['warna'] == 'Hitam') echo 'selected'; ?>>Hitam</option>
                            <option value="Putih" <?php if ($hewan['warna'] == 'Putih') echo 'selected'; ?>>Putih</option>
                            <option value="Cokelat" <?php if ($hewan['warna'] == 'Cokelat') echo 'selected'; ?>>Cokelat</option>
                            <option value="Abu-abu" <?php if ($hewan['warna'] == 'Abu-abu') echo 'selected'; ?>>Abu-abu</option>
                            <option value="Lain-lain" <?php if ($hewan['warna'] == 'Lain-lain') echo 'selected'; ?>>Lain-lain</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="stok" class="form-label">Stok</label>
                        <select class="form-control" id="stok" name="stok" required>
                            <option value="">Pilih Stok</option>
                            <option value="1" <?php if ($hewan['stok'] == '1') echo 'selected'; ?>>1</option>
                            <option value="5" <?php if ($hewan['stok'] == '5') echo 'selected'; ?>>5</option>
                            <option value="10" <?php if ($hewan['stok'] == '10') echo 'selected'; ?>>10</option>
                            <option value="20" <?php if ($hewan['stok'] >= '20') echo 'selected'; ?>>20+</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="harga" class="form-label">Harga</label>
                        <select class="form-control" id="harga" name="harga" required>
                            <option value="">Pilih Harga</option>
                            <option value="10000" <?php if ($hewan['harga'] == '10000') echo 'selected'; ?>>Rp 10.000</option>
                            <option value="50000" <?php if ($hewan['harga'] == '50000') echo 'selected'; ?>>Rp 50.000</option>
                            <option value="100000" <?php if ($hewan['harga'] == '100000') echo 'selected'; ?>>Rp 100.000</option>
                            <option value="500000" <?php if ($hewan['harga'] >= '500000') echo 'selected'; ?>>Rp 500.000+</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                    <a href="<?php echo base_url('index.php/hewan'); ?>" class="btn btn-secondary">Batal</a>
                </form>
            </div>
        </div>
    </div>
</div>
</div>
<?php $this->load->view('template/footer'); ?>