<?php $this->load->view('template/head'); ?>

</div>
<?php $this->load->view('template/sidebar'); ?>

<div class="main-panel">
    <div class="content">
        <div class="container-fluid">
            <h4 class="page-title">ANGGERRRRRRRR</h4>
            <div class="row">
                <div class="col-md-3">
                    <div class="card card-stats card-warning">
                    </div>
                </div>
            </div>
            <div class="card-body">
                <h5 class="card-title">HEWAN</h5>
                <a href="<?php echo base_url('index.php/hewan/tambah'); ?>" class="btn btn-primary mb-3">Tambah Hewan</a>
                <div class="table-responsive" style="overflow-x: auto;">
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>NO</th>
                                <th>NAMA</th>
                                <th>JENIS</th>
                                <th>WARNA</th>
                                <th>STOK</th>
                                <th>HARGA</th>
                                <th>AKSI</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($hewan)): ?>
                                <tr><td colspan="7">Tidak ada data hewan.</td></tr>
                            <?php else: ?>
                                <?php $no = 1; ?>
                                <?php foreach ($hewan as $row): ?>
                                    <tr>
                                        <td><?php echo $no++; ?></td>
                                        <td><?php echo $row['nama']; ?></td>
                                        <td><?php echo $row['jenis']; ?></td>
                                        <td><?php echo $row['warna']; ?></td>
                                        <td><?php echo $row['stok']; ?></td>
                                        <td>Rp <?php echo number_format($row['harga'], 2, ',', '.'); ?></td>
                                        <td>
                                            <a href="<?php echo site_url('index.php/hewan/edit/' . $row['no']); ?>">Edit</a> |
                                            <a href="<?php echo site_url('index.php/hewan/hapus/' . $row['no']); ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
<?php $this->load->view('template/footer'); ?>