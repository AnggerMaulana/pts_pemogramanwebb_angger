<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Hewan extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Hewan_m');
    }

    public function index()
    {
        $data['hewan'] = $this->Hewan_m->get_all();
        $this->load->view('hewan', $data);
    }

    public function tambah()
    {
        $this->load->view('tambah');
    }

    public function tambah_aksi()
    {
        $nama = $this->input->post('nama');
        $jenis = $this->input->post('jenis');
        $warna = $this->input->post('warna');
        $stok = $this->input->post('stok');
        $harga = $this->input->post('harga');

        $data = array(
            'nama' => $nama,
            'jenis' => $jenis,
            'warna' => $warna,
            'stok' => $stok,
            'harga' => $harga
        );

        $this->Hewan_m->insert_hewan($data);
        redirect('index.php/hewan');
    }

    public function edit($id)
    {
        $data['hewan'] = $this->Hewan_m->get_by_id($id);
        $this->load->view('edit', $data);
    }

    public function edit_aksi()
    {
        $id = $this->input->post('no'); // Asumsi primary key di tabel hewan adalah 'no'
        $nama = $this->input->post('nama');
        $jenis = $this->input->post('jenis');
        $warna = $this->input->post('warna');
        $stok = $this->input->post('stok');
        $harga = $this->input->post('harga');

        $data = array(
            'nama' => $nama,
            'jenis' => $jenis,
            'warna' => $warna,
            'stok' => $stok,
            'harga' => $harga
        );

        $this->Hewan_m->update_hewan($id, $data);
        redirect('index.php/hewan');
    }

    public function hapus($id)
    {
        $this->Hewan_m->delete_hewan($id);
        redirect('index.php/hewan');
    }
}